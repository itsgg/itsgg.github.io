> [!info] Build intentional habits aligned with your core values.

## New Habit

> [!tip] Clearly define new habit.

{TBD}

---

## Existing Habit

> [!tip] Identify existing habit as trigger.

{TBD}

---

## Habit Stack Formula

> [!tip] Clearly define the habit stacking formula.

After {Existing Habit}, I will {New Habit}.

---

## Habit Tracking

> [!tip] Track your progress clearly.

| Date     | Done | Notes    |
| -------- | ---- | -------- |
| {Date 1} | [ ]  | {Note 1} |
| {Date 2} | [ ]  | {Note 2} |
| {Date 3} | [ ]  | {Note 3} |
